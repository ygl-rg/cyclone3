# coding: utf-8
#
$license

__author__ = "$name <$email>"
__version__ = "$version"
